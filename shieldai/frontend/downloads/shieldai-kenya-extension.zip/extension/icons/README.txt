Icons needed:
- icon16.png (16x16 pixels)
- icon48.png (48x48 pixels) 
- icon128.png (128x128 pixels)

For now, you can use any simple Kenya-themed icons.
You can generate these using free online icon generators.